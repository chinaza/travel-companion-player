# Travelling Companion HTML5 video player
A simple HTML5 video player <> with Electron for the Travel Companion
